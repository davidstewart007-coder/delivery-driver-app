DELIVERY TRACKER — IPHONE SETUP

1. Create a GitHub repository named delivery-driver.
2. Upload all five files in this folder to the repository root.
3. In GitHub open Settings > Pages.
4. Choose Deploy from a branch, select main and /(root), then Save.
5. Once published, open https://YOUR-USERNAME.github.io/delivery-driver/ in Safari.
6. Tap Share > Add to Home Screen > Add. Launch it from the new icon.

Includes £2.70, £3.00, £3.20, £3.50 and £5.00 buttons, custom delivery amounts,
separate takeaway fuel payments, shift totals, delete-entry controls, saved shift
history and offline app-shell caching after first online visit.

Entries are stored locally on this iPhone in Safari. They do not sync or back up
automatically. Open online once before relying on offline mode.
